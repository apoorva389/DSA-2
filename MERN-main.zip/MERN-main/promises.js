// const promise=new Promise((resolve,reject)=>{
//     reject("data not fetched successfully");

// })
// promise.then((result)=>{
//     console.log(result);
// }).catch((error)=>{
// console.log(error);})

// const promise=new Promise((resolve,reject)=>{
//     setTimeout(() => {
//         resolve("data received after 4 secs")
//     }, 4000);
// })
// promise.then((result)=>{
//     console.log(result);
// }).catch((error)=>{
// console.log(error);})

// console.log("1");//microtask

// setTimeout(() => console.log("2"), 0);  // macrotask

// Promise.resolve().then(() => console.log("3"));  // microtask

// console.log("4");

function sayHello() {                          // regular function
  return new Promise((resolve) => {             // create a promise
    setTimeout(() => {                          // wait using a timer (macrotask)
      resolve("hello");                         // after time passes, resolve with "hello"
    }, 2000);                                   // wait 2 seconds
  });
}

async function greet() {                        // async function
  console.log("start");                         // runs immediately (sync)
  
  const message = await sayHello();             // pause here until promise resolves
  console.log(message);                          // runs after 2 secs, prints "hello"
}

greet();                                         // call the function
console.log("end");                              // runs immediately, before "hello"


async function getTodo() {                                          // async function
  const response = await fetch('https://jsonplaceholder.typicode.com/todos/1'); // pause until fetch resolves (gets raw response)
  const json = await response.json();                                // pause until response.json() promise resolves (parses body)
  console.log(json);                                                 // log the parsed data
}

getTodo();                                                            // call the function


async function getdata() {
  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/users'); // pause until fetch completes
    const json = await response.json();                                           // pause until body is parsed
const names=json.map(user=>user.name);
console.log(names);                                                       // success case
  } 
  catch (error) {
    console.log("something went wrong:", error);                                 // runs if fetch fails or json parsing fails
  }
}

getdata();

