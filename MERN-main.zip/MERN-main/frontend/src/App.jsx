import React from 'react'
import User from './components/User'


const App = () => {
  let name="soo"
  return (
    <>
    <User name="soo" dept="aiml"/>
    <h1>hello {name}</h1>
    <p></p>
    </>
    
  )
}
 
export default App