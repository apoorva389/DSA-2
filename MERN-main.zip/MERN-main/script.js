// console.log("hello world");
var a=10;
var a=20;//re-declaration is possible in var
console.log(a);
let b=5;
// let b=10; //redeclaration is not possible in let
console.log(b);
let c=20;
// c=30;
// console.log(c); //reassignment is not possible in let
const d=10;
console.log(d);//fixed value
//cant redeclare or reassign

//scope:
var x=10;
{
    var x=20;
}
console.log(x);
let y=20;
{
 let y=30;  
}
 console.log(y);
 //primitive:
 let name="xyz";
 let issStudent=true;
 let dept=null;
 console.log(typeof name); 
 console.log(typeof issStudent); 
 console.log(typeof dept); 
 //Non-primitive:
 let obj={
    name:"A",
    age:20
 }
 let copy=obj;
 copy.age=30;//updates the age
 console.log(obj.age);
 
 //operator
 console.log(5=="5");//java
 console.log(5==="5");//javascript

 //falsy-truthy
console.log(0||"Default");
console.log(1||"Default");

//null coalshing(??)
let value=null;
console.log(value??"Default");
let value2=null;
console.log(value2??18);

//ternary operator:
let age=20;
console.log(age>=18?"Adult":"minor");

//hoisting:
console.log(e);
var e=80;
//function:

function greet(name){
    console.log("Hello"+ name);
}//greet("QWERTY");

//Arrow function:
const greet1=()=>{
    return "Hello";
}
console.log(greet1());
greet("Qwerty");
 
// callback function:
function greet(name){
    console.log("hello"+name);
} 
function fun(callback){
    let name="from callback";
    callback(name);
}
fun(greet);

//string literals:
let name1="soo";
let dept1="CSE"
console.log("i am "+ name1 +" from "+ dept1);//old way
//template litreals
console.log(`i am ${name1} from ${dept1}`);//string literals

//ARRAYS:
let mixed = ["Sonali", 21, true, [1, 2, 3]];
//access array
console.log(mixed[0]); 
mixed.push(20);
console.log(mixed);
mixed.pop();
console.log(mixed);
mixed.unshift(10);//adds 10 to the start 
console.log(mixed);
mixed.shift();//removes 10 from the start
console.log(mixed);
